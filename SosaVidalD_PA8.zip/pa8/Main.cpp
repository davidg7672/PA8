/*
David Sosa Vidal
CPSC 122
Professor Jacob Shea
Programming Assignment 8, Doubly Linked List and Queues
Main Function File
*/

#include "PA8.h"

// no need for any changes here
int main(void) {
	// Does everything
	runPrimesPrompt();
	
	return 0;
}