/*
David Sosa Vidal
CPSC 122
Professor Jacob Shea
Programming Assignment 8, Doubly Linked List and Queues
PA8 Head File
*/

#ifndef PA8_H
#define PA8_H

#include <iostream>
#include "Sieve.h"

using namespace std;

void runPrimesPrompt();

#endif